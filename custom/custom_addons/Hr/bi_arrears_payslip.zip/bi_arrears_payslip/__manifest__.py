{
    "name": "Arrears",
    "summary": """
        payslip""",
    "description": """
        Long description of module's purpose
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Uncategorized",
    "version": "16.0.2",
    "depends": ["base","hr_payroll","hr_contract"],
    "data": [
                "security/ir.model.access.csv",
                "views/arrears_model.xml",
                "views/hike_field_contract.xml",
                "views/arrears_salary_rule.xml",
                "views/arrears_input_type.xml",



    ],
}
