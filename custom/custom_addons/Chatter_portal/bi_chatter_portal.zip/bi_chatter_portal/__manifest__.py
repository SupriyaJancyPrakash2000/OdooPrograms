{
    "name": "chatbox replace",
    "summary": """
        hr""",
    "description": """
        Long description of module's purpose
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Uncategorized",
    "version": "15.0.0.2",
    "depends": ["web","portal"],
    'assets': {
        'web.assets_frontend': [
            'bi_chatter_portal/static/src/xml/chatter_portal_replace.xml'
        ],
        }
}
